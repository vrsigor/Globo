package Teste_Globo;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertSame;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

class globo {

	public List<MobileElement> optionCount;
	AppiumDriver<MobileElement> driver;

	public void setUp() throws MalformedURLException {

		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setCapability("platformName", "Android");
		cap.setCapability("deviceName", "Moto Z2 Play");
		cap.setCapability("browserName", "Chrome");
		driver = new AndroidDriver<MobileElement>(new URL("http://localhost:4723/wd/hub"), cap);
		driver.get("https://m.oglobo.globo.com/fotogalerias/");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

	}

	public void validaPhotoGaleria() throws InterruptedException {

		WebElement ul_Element = driver.findElement(By.className("recommended"));
		List<WebElement> li_All = ul_Element.findElements(By.tagName("li"));
		assertSame(6, li_All.size());

		if (li_All.size() == 6) {
			System.out.println("Photo Galeria possui 6 fotos como esperado.");
		} else {
			System.out.println("Photo Galeria n�o possui 6 fotos como esperado.");
		}

	}

	public void validaMaisVistas() throws InterruptedException {

		WebElement ul_Element = driver.findElement(By.className("popular"));
		List<WebElement> li_All = ul_Element.findElements(By.tagName("li"));
		assertSame(3, li_All.size());

		if (li_All.size() == 3) {
			System.out.println("Mais Vistas possui 3 fotos como esperado.");
		} else {
			System.out.println("Mais Vistas n�o possui 3 fotos como esperado.");
		}

	}
	
	public void validaUltimas() throws InterruptedException {

		WebElement ul_Element = driver.findElement(By.id("listaConteudosMobi"));
		List<WebElement> li_All = ul_Element.findElements(By.tagName("li"));
		//assertSame(3, li_All.size());

		if (li_All.size() == 3) {
			System.out.println("Ultimas possui 3 fotos como esperado.");
		} else {
			System.out.println("Ultimas n�o possui 3 fotos como esperado.");
		}

	}

	public void validaCombo() throws InterruptedException {

		Select comboBox = new Select(driver.findElement(By.id("selectEditorias")));
		String selectedComboValue = comboBox.getFirstSelectedOption().getText();
		//assertTrue(selectedComboValue.equals("Todas"));
		
		if (selectedComboValue.equals("Todas")) {
			System.out.println("Combo selecionado na op��o Todas como esperado.");
		} else {
			System.out.println("Combo n�o selecionado na op��o Todas como esperado.");
		}

	}

	public void tearDown() throws InterruptedException {
		Thread.sleep(5000);
		driver.quit();

	}

	public static void main(String[] args) throws MalformedURLException, InterruptedException {

		globo obj = new globo();
		obj.setUp();
		obj.validaPhotoGaleria();
		obj.validaMaisVistas();
		obj.validaUltimas();
		obj.validaCombo();
		obj.tearDown();
	}

}